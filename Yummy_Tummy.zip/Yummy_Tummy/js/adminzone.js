function show(){
    var a=document.getElementById('title').style;
    var b=document.getElementById('mealPlan').style;
    var c=document.getElementById('User').style;
    var d=document.getElementById('userFeedback').style;
    var e=document.getElementById('order').style;
    a.opacity='1';
    a.transition='5s';
  
    b.marginTop='0px';
   // b.marginLeft='180px';
    b.transition='3s';
      c.marginTop='-200px';
      
    c.transition='4s';
   // c.margiLeft='400px';
      d.marginTop='-200px';
    d.transition='5s';
   // d.marginLeft='600px';
   e.transition='6s';
   e.marginTop='-200px';
}