function print(){
	window.print();
	document.getElementById('print').type="hidden";
}