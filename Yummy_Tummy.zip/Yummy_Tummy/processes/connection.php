<?php
$host='localhost';
$username='root';
$password='';
$dbname='hungrypet';
$conn=@mysqli_connect($host,$username,$password,$dbname);
if(!$conn)
    die("Connection Error");
?>

